package com.example.myexam;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import retrofit2.Callback;
import retrofit2.Response;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.nfc.Tag;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.utils.Transformer;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.slider.LabelFormatter;


import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class AdminMain extends AppCompatActivity {
    //private static Tag="AdminMain";
    private int[] yDataMeeting = new int[2];
    private String[] xDataMeeting = {"active", "not active"};

    private int[] yDataParent = new int[2];
    private String[] xDataParent = {"new", "old"};

    private int[] yDataKid = new int[2];
    private String[] xDataKid = {"new", "old"};
    Context ctx = this;

    private BarChart barChart;
    private int[] yDataTotal = {210, 140, 70, 80};
    private String[] xDataTotal = {"sport", "space", "art", "math"};
    private PieChart pieChartHours, pieChartParents, pieChartKids, pieChartTotal;
    private TextView numberOfHours, numberOfParents, numberOfKids;
    private Button yearlyBtn, monthlyBtn, weeklyBtn;
    private int timecontrol = 2;
    private BottomNavigationView navigationView;
    ///////////

    ArrayList<String> labels = new ArrayList<>();


    ////////////////

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_main);
///////////////////////
        yearlyBtn = findViewById(R.id.yearlyBtn);
        monthlyBtn = findViewById(R.id.monthlyBtn);
        weeklyBtn = findViewById(R.id.weeklyBtn);
        barChart = findViewById(R.id.barChartAdmin);
        monthlyBtn.setBackgroundColor(Color.parseColor("#5377ee"));
        navigationView = findViewById(R.id.navibarAdminMain);

        final FragmentManager fragmentManager = getSupportFragmentManager();

        // define your fragments here
        final Fragment fragment1 = new UserFragment();
        final Fragment fragment2 = new LeadersFragment();
        final Fragment fragment3 = new CoursesFragment();
        final Fragment fragment4 = new CategoryFragment();
        final Fragment fragment5 = new MoreFragment();

        navigationView.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {


                        switch (item.getItemId()) {
                            case R.id.bottomNavigationUserMenuId:
//                                Intent intent=new Intent(AdminMain.this, AdminMain.class);
//
//                                startActivity(intent);
                                Fragment myFragment = (Fragment)getSupportFragmentManager().findFragmentByTag("MY_FRAGMENT");
                                if (myFragment != null && myFragment.isVisible()) {
                                    fragmentManager.beginTransaction().remove(myFragment).commitAllowingStateLoss();
                                }

                                break;
                            case R.id.bottomNavigationLeadersMenuId:
                                fragmentManager.beginTransaction().replace(R.id.adminlayout, fragment2, "MY_FRAGMENT")
                                        .commitAllowingStateLoss();


                                break;
                            case R.id.bottomNavigationCategorytMenuId:
                                fragmentManager.beginTransaction().replace(R.id.adminlayout, fragment4, "MY_FRAGMENT")
                                        .commitAllowingStateLoss();
                                break;
                            case R.id.bottomNavigationCoursesMenuId:
                                fragmentManager.beginTransaction().replace(R.id.adminlayout, fragment3, "MY_FRAGMENT")
                                        .commitAllowingStateLoss();

                                break;
                            case R.id.bottomNavigationMoreMenuId:
//                                fragmentManager.beginTransaction().replace(R.id.adminlayout, fragment5, "MY_FRAGMENT")
//                                        .commitAllowingStateLoss();
                                PopupMenu popup = new PopupMenu(AdminMain.this, findViewById(R.id.bottomNavigationMoreMenuId));
                                MenuInflater inflater = popup.getMenuInflater();
                                inflater.inflate(R.menu.mymenu, popup.getMenu());
                                popup.show();

                                break;

                        }


                        return true;
                    }
                });

        /////////////////////////
        initBarChart();
        showBarChart();
        buildchart();
        yearlyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                yearlyBtn.setBackgroundResource(R.drawable.myrect);
                monthlyBtn.setBackgroundResource(R.drawable.myrect8);
                weeklyBtn.setBackgroundResource(R.drawable.myrect5);
                timecontrol = 1;
                buildchart();
                initBarChart();
                showBarChart();
            }
        });
        monthlyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timecontrol = 2;
                yearlyBtn.setBackgroundResource(R.drawable.myrect4);
                monthlyBtn.setBackgroundColor(Color.parseColor("#5377ee"));
                weeklyBtn.setBackgroundResource(R.drawable.myrect5);
                buildchart();
                initBarChart();
                showBarChart();
            }
        });
        weeklyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timecontrol = 3;
                yearlyBtn.setBackgroundResource(R.drawable.myrect4);
                weeklyBtn.setBackgroundResource(R.drawable.myrect7);
                monthlyBtn.setBackgroundResource(R.drawable.myrect8);
                buildchart();
                initBarChart();
                showBarChart();
            }
        });


    }


    void buildchart() {
        // System.out.println(timecontrol);
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://10.0.2.2:9091/")
                // when sending data in json format we have to add Gson converter factory
                .addConverterFactory(GsonConverterFactory.create())
                // and build our retrofit builder.
                .build();
        // create an instance for our retrofit api class.
        RetrofitAPI retrofitAPI = retrofit.create(RetrofitAPI.class);

        Call<int[]> callHour = retrofitAPI.getMeetingsStat(timecontrol);
        callHour.enqueue(new Callback<int[]>() {
            @Override
            public void onResponse(Call<int[]> call, Response<int[]> response) {
                yDataMeeting = response.body();
                SharedPreferences pref = getApplicationContext().getSharedPreferences("MyKIDIPref", 0); // 0 - for private mode
                SharedPreferences.Editor editor = pref.edit();
                editor.putInt("hours", yDataMeeting[0]);
                editor.putInt("hoursPercentage", yDataMeeting[1]);
                editor.commit();

            }

            @Override
            public void onFailure(Call<int[]> call, Throwable t) {

                SharedPreferences pref = getApplicationContext().getSharedPreferences("MyKIDIPref", 0); // 0 - for private mode
                SharedPreferences.Editor editor = pref.edit();
                editor.putInt("hours", 10);
                editor.putInt("hoursPercentage", 40);
                editor.commit();
            }
        });
        Call<int[]> callParent = retrofitAPI.getParentsStat(timecontrol);
        callParent.enqueue(new Callback<int[]>() {
            @Override
            public void onResponse(Call<int[]> call, Response<int[]> response) {
                yDataParent = response.body();
                SharedPreferences pref = getApplicationContext().getSharedPreferences("MyKIDIPref", 0); // 0 - for private mode
                SharedPreferences.Editor editor = pref.edit();
                editor.putInt("ParentsNumber", yDataParent[0]);
                editor.putInt("ParentsPercentage", yDataParent[1]);
                editor.commit();

            }

            @Override
            public void onFailure(Call<int[]> call, Throwable t) {
                SharedPreferences pref = getApplicationContext().getSharedPreferences("MyKIDIPref", 0); // 0 - for private mode
                SharedPreferences.Editor editor = pref.edit();
                editor.putInt("ParentsNumber", 20);
                editor.putInt("ParentsPercentage", 80);
                editor.commit();
            }
        });
        Call<int[]> callKid = retrofitAPI.getKidsStat(timecontrol);
        callKid.enqueue(new Callback<int[]>() {
            @Override
            public void onResponse(Call<int[]> call, Response<int[]> response) {
                yDataKid = response.body();
                SharedPreferences pref = getApplicationContext().getSharedPreferences("MyKIDIPref", 0); // 0 - for private mode
                SharedPreferences.Editor editor = pref.edit();
                editor.putInt("KidsNumber", yDataKid[0]);
                editor.putInt("KidsPercentage", yDataKid[1]);
                editor.commit();

            }

            @Override
            public void onFailure(Call<int[]> call, Throwable t) {
                SharedPreferences pref = getApplicationContext().getSharedPreferences("MyKIDIPref", 0); // 0 - for private mode
                SharedPreferences.Editor editor = pref.edit();
                editor.putInt("KidsNumber", 23);
                editor.putInt("KidsPercentage", 65);
                editor.commit();
            }
        });


        ////////////////////////////

        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyKIDIPref", 0); // 0 - for private mode
        SharedPreferences.Editor editor = pref.edit();
        yDataMeeting[0] = pref.getInt("hours", 0); // getting
        yDataMeeting[1] = pref.getInt("hoursPercentage", 0); // getting

        yDataParent[0] = pref.getInt("ParentsNumber", 0); // getting
        yDataParent[1] = pref.getInt("ParentsPercentage", 0); // getting

        yDataKid[0] = pref.getInt("KidsNumber", 0); // getting
        yDataKid[1] = pref.getInt("KidsPercentage", 0); // getting

        numberOfHours = findViewById(R.id.numberOfHours);
        numberOfHours.setText(String.valueOf(yDataMeeting[1])+"%");

        numberOfParents = findViewById(R.id.numberOfNewParents);
        numberOfParents.setText(String.valueOf(yDataParent[1])+"%");

        numberOfKids = findViewById(R.id.numberOfNewKids);
        numberOfKids.setText(String.valueOf(yDataKid[1])+"%");


        barChart = findViewById(R.id.barChartAdmin);


        //////////////////////////////
        pieChartHours = findViewById(R.id.idPieChartHours);
        pieChartParents = findViewById(R.id.idPieChartParent);
        pieChartKids = findViewById(R.id.idPieChartKids);
        pieChartTotal = findViewById(R.id.idPieChartTotal);
        // pieChart.setDescription("Sales by employee (In Thousands $) ");
        pieChartHours.setRotationEnabled(false);
        pieChartHours.setUsePercentValues(false);
        //pieChart.setHoleColor(Color.BLUE);
        //pieChart.setCenterTextColor(Color.BLACK);
        pieChartHours.setHoleRadius(80f);
        pieChartHours.setTransparentCircleAlpha(0);
        pieChartHours.setCenterText(String.valueOf(yDataMeeting[0]));//number of hours
        pieChartHours.setCenterTextTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
        pieChartHours.setCenterTextSize(20);
        pieChartHours.getDescription().setEnabled(false);
        pieChartHours.setHighlightPerTapEnabled(false);
//////////////////////////////////

        // pieChart.setDescription("Sales by employee (In Thousands $) ");
        pieChartParents.setRotationEnabled(false);
        pieChartParents.setUsePercentValues(false);
        //pieChart.setHoleColor(Color.BLUE);
        //pieChart.setCenterTextColor(Color.BLACK);
        pieChartParents.setHoleRadius(80f);
        pieChartParents.setTransparentCircleAlpha(0);
        pieChartParents.setCenterText(String.valueOf(yDataParent[0]));
        pieChartParents.setCenterTextSize(20);
        pieChartParents.setCenterTextTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
        pieChartParents.getDescription().setEnabled(false);
        pieChartParents.setHighlightPerTapEnabled(false);
        /////////////////////////////////////////////////


        pieChartKids.setRotationEnabled(false);
        pieChartKids.setUsePercentValues(false);
        //pieChart.setHoleColor(Color.BLUE);
        //pieChart.setCenterTextColor(Color.BLACK);
        pieChartKids.setHoleRadius(80f);
        pieChartKids.setTransparentCircleAlpha(0);
        pieChartKids.setCenterText(String.valueOf(yDataKid[0]));
        pieChartKids.setCenterTextSize(20);
        pieChartKids.setCenterTextTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
        pieChartKids.getDescription().setEnabled(false);
        pieChartKids.setHighlightPerTapEnabled(false);
        //////////////////////////////////////////////

        pieChartTotal.setRotationEnabled(false);
        pieChartTotal.setUsePercentValues(false);
        pieChartTotal.setHoleRadius(0f);
        pieChartTotal.setTransparentCircleAlpha(0);
        //pieChartTotal.setCenterText("250");
        //pieChartTotal.setCenterTextSize(10);
        pieChartTotal.getDescription().setEnabled(false);
        pieChartTotal.setHighlightPerTapEnabled(false);
        addDataSetHours();
        addDataSetTotal();
        addDataSetParents();
        addDataSetKids();
    }


    private void addDataSetHours() {

        ArrayList<PieEntry> yEntrys = new ArrayList<>();
        ArrayList<String> xEntrys = new ArrayList<>();


        for (int i = 0; i < xDataMeeting.length; i++) {
            xEntrys.add(xDataMeeting[i]);
        }
        yEntrys.add(new PieEntry(yDataMeeting[1], 0));
        yEntrys.add(new PieEntry(100 - yDataMeeting[1], 1));

        //create the data set
        PieDataSet pieDataSet = new PieDataSet(yEntrys, "         Activities In Hour");
        pieDataSet.setSliceSpace(2);
        pieDataSet.setValueTextSize(12);


        //add colors to dataset
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.parseColor("#5377ee"));
        colors.add(Color.parseColor("#d0dbff"));

        colors.add(Color.RED);
        colors.add(Color.GREEN);
        colors.add(Color.CYAN);

        colors.add(Color.YELLOW);
        colors.add(Color.MAGENTA);

        pieDataSet.setColors(colors);
        pieDataSet.setDrawValues(false);
        pieDataSet.setSliceSpace(0f);
        pieChartHours.setDrawSliceText(false);
        //add legend to chart
        Legend legend = pieChartHours.getLegend();
        legend.setForm(Legend.LegendForm.NONE);
        // legend.setPosition(Legend.LegendPosition.LEFT_OF_CHART);
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        // legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legend.setDrawInside(false);
        //create pie data object
        PieData pieData = new PieData(pieDataSet);
        pieChartHours.setData(pieData);

        pieChartHours.invalidate();
        //pieChart.getLegend().setEnabled(false);


        ////////////////////////////////

    }

    private void addDataSetTotal() {
        ArrayList<PieEntry> yEntrysTotal = new ArrayList<>();
        ArrayList<String> xEntrysTotal = new ArrayList<>();
        for (int i = 0; i < yDataTotal.length; i++) {
            yEntrysTotal.add(new PieEntry(yDataTotal[i], i));
        }

        for (int i = 0; i < xDataTotal.length; i++) {
            xEntrysTotal.add(xDataTotal[i]);
        }
        PieDataSet pieDataSetTotal = new PieDataSet(yEntrysTotal, "     Total Per Category");
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.parseColor("#5377ee"));
        colors.add(Color.parseColor("#edc655"));


        colors.add(Color.parseColor("#0091ff"));
        colors.add(Color.parseColor("#d0dbff"));
        colors.add(Color.GRAY);
        colors.add(Color.YELLOW);
        colors.add(Color.MAGENTA);

        pieDataSetTotal.setSliceSpace(2);
        pieDataSetTotal.setValueTextSize(12);
        pieDataSetTotal.setColors(colors);
        pieDataSetTotal.setDrawValues(true);
        pieDataSetTotal.setSliceSpace(0f);
        // pieChartTotal.setDrawSliceText(false);
        //add legend to chart

        pieDataSetTotal.setValueTextColor(Color.WHITE);
        pieDataSetTotal.setColors(colors);
        pieDataSetTotal.setDrawValues(true);
        pieDataSetTotal.setSliceSpace(0f);
        pieChartTotal.setDrawSliceText(true);
        ValueFormatter vf = new ValueFormatter() { //value format here, here is the overridden method
            @Override
            public String getFormattedValue(float value) {
                return "" + (int) value;
            }
        };
        pieDataSetTotal.setValueFormatter(vf);
        Legend legendTotal = pieChartTotal.getLegend();
        legendTotal.setForm(Legend.LegendForm.NONE);

        // legend.setPosition(Legend.LegendPosition.LEFT_OF_CHART);
        legendTotal.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legendTotal.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        // legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legendTotal.setDrawInside(false);
        //create pie data object
        PieData pieDataTotal = new PieData(pieDataSetTotal);
        pieChartTotal.setData(pieDataTotal);

        pieChartTotal.invalidate();
    }

    private void addDataSetParents() {

        ArrayList<PieEntry> yEntrys = new ArrayList<>();
        ArrayList<String> xEntrys = new ArrayList<>();


        for (int i = 0; i < xDataParent.length; i++) {
            xEntrys.add(xDataParent[i]);
        }
        yEntrys.add(new PieEntry(yDataParent[1], 0));
        yEntrys.add(new PieEntry(100 - yDataParent[1], 1));


        //create the data set
        PieDataSet pieDataSet = new PieDataSet(yEntrys, "               New Parents");
        pieDataSet.setSliceSpace(2);
        pieDataSet.setValueTextSize(12);


        //add colors to dataset
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.parseColor("#edc655"));
        colors.add(Color.parseColor("#d0dbff"));

        colors.add(Color.RED);
        colors.add(Color.GREEN);
        colors.add(Color.CYAN);

        colors.add(Color.YELLOW);
        colors.add(Color.MAGENTA);

        pieDataSet.setColors(colors);
        pieDataSet.setDrawValues(false);
        pieDataSet.setSliceSpace(0f);
        pieChartParents.setDrawSliceText(false);
        //add legend to chart
        Legend legend = pieChartParents.getLegend();
        legend.setForm(Legend.LegendForm.NONE);
        // legend.setPosition(Legend.LegendPosition.LEFT_OF_CHART);
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        // legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legend.setDrawInside(false);
        //create pie data object
        PieData pieData = new PieData(pieDataSet);
        pieChartParents.setData(pieData);

        pieChartParents.invalidate();
        //pieChart.getLegend().setEnabled(false);


        ////////////////////////////////

    }

    private void addDataSetKids() {

        ArrayList<PieEntry> yEntrys = new ArrayList<>();
        ArrayList<String> xEntrys = new ArrayList<>();


        for (int i = 0; i < xDataKid.length; i++) {
            xEntrys.add(xDataKid[i]);
        }
        yEntrys.add(new PieEntry(yDataKid[1], 0));
        yEntrys.add(new PieEntry(100 - yDataKid[1], 1));


        //create the data set
        PieDataSet pieDataSet = new PieDataSet(yEntrys, "                  New Children");
        pieDataSet.setSliceSpace(2);
        pieDataSet.setValueTextSize(12);


        //add colors to dataset
        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.parseColor("#0091ff"));
        colors.add(Color.parseColor("#d0dbff"));


        colors.add(Color.GREEN);
        colors.add(Color.CYAN);

        colors.add(Color.YELLOW);
        colors.add(Color.MAGENTA);

        pieDataSet.setColors(colors);
        pieDataSet.setDrawValues(false);
        pieDataSet.setSliceSpace(0f);
        pieChartKids.setDrawSliceText(false);
        //add legend to chart
        Legend legend = pieChartKids.getLegend();
        legend.setForm(Legend.LegendForm.NONE);
        // legend.setPosition(Legend.LegendPosition.LEFT_OF_CHART);
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        // legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legend.setDrawInside(false);
        //create pie data object
        PieData pieData = new PieData(pieDataSet);
        pieChartKids.setData(pieData);

        pieChartKids.invalidate();
        //pieChart.getLegend().setEnabled(false);


        ////////////////////////////////

    }

    //function responsible for capturing data input and output the bar chart with the data.
    private void showBarChart() {
        int barnum = 1;
        ArrayList<Double> valueList = new ArrayList<Double>();
        ArrayList<Double> valueList2 = new ArrayList<Double>();
        ArrayList<Double> valueList3 = new ArrayList<Double>();
        ArrayList<Double> valueList4 = new ArrayList<Double>();
        ArrayList<Double> valueList5 = new ArrayList<Double>();


        ArrayList<BarEntry> entries = new ArrayList<>();
        ArrayList<BarEntry> entries2 = new ArrayList<>();
        ArrayList<BarEntry> entries3 = new ArrayList<>();
        ArrayList<BarEntry> entries4 = new ArrayList<>();
        ArrayList<BarEntry> entries5 = new ArrayList<>();


        //input data
        switch (timecontrol) {
            case 1:
                barnum = 12;
                break;
            case 2:
                barnum = 5;
                break;
            case 3:
                barnum = 7;
                break;

        }
        for (int i = 1; i <= barnum; i++) {
            valueList.add(i * 80.1);
        }
        for (int i = 1; i <= barnum; i++) {
            valueList2.add(i * 50.1);
        }
        for (int i = 1; i <= barnum; i++) {
            valueList3.add(i * 20.1);
        }
        for (int i = 1; i <= barnum; i++) {
            valueList4.add(i * 90.1);
        }
        for (int i = 1; i <= barnum; i++) {
            valueList5.add(i * 70.1);
        }


        //fit the data into a bar
        for (int i = 0; i < valueList.size(); i++) {
            BarEntry barEntry = new BarEntry(i, valueList.get(i).floatValue());
            entries.add(barEntry);

            BarEntry barEntry2 = new BarEntry(i, valueList2.get(i).floatValue());
            entries2.add(barEntry2);

            BarEntry barEntry3 = new BarEntry(i, valueList3.get(i).floatValue());
            entries3.add(barEntry3);

            BarEntry barEntry4 = new BarEntry(i, valueList4.get(i).floatValue());
            entries4.add(barEntry4);

            BarEntry barEntry5 = new BarEntry(i, valueList5.get(i).floatValue());
            entries5.add(barEntry5);
        }

        BarDataSet barDataSet = new BarDataSet(entries, "sport");
        barDataSet.setColors(Color.parseColor("#5377ee"));
        BarDataSet barDataSet2 = new BarDataSet(entries2, "math");
        barDataSet2.setColors(Color.parseColor("#edc655"));
        BarDataSet barDataSet3 = new BarDataSet(entries3, "science");
        barDataSet3.setColors(Color.parseColor("#0091ff"));
        BarDataSet barDataSet4 = new BarDataSet(entries4, "art");
        barDataSet4.setColors(Color.parseColor("#d0dbff"));
        BarDataSet barDataSet5 = new BarDataSet(entries5, "space");
        barDataSet5.setColors(R.color.white);


        ArrayList<IBarDataSet> dataSets = new ArrayList<IBarDataSet>();
        dataSets.add(barDataSet);
        dataSets.add(barDataSet2);
        dataSets.add(barDataSet3);
        dataSets.add(barDataSet4);
        dataSets.add(barDataSet5);


        BarData data = new BarData(dataSets);
        ;


        barChart.setData(data);
        barChart.setScaleEnabled(false);


        switch (timecontrol) {
            case 1:
                data.setBarWidth(0.1f);
                barChart.setVisibleXRangeMaximum(6f);
                barChart.groupBars(-0.3f, 0.48f, 0f);
                break;
            case 2:
                data.setBarWidth(0.1f);
                barChart.setVisibleXRangeMaximum(3f);
                barChart.groupBars(-0.45f, 0.5f, 0f);
                break;
            case 3:
                data.setBarWidth(0.1f);
                barChart.setVisibleXRangeMaximum(3f);
                barChart.groupBars(-0.45f, 0.5f, 0f);
                break;

        }
        barChart.invalidate();
//        BarData data = new BarData(barDataSet);
//        barChart.setData(data);
//        barChart.invalidate();
        initBarDataSet(barDataSet);
        initBarDataSet(barDataSet2);
        initBarDataSet(barDataSet3);
        initBarDataSet(barDataSet4);
        initBarDataSet(barDataSet5);

    }

    //function  responsible for the appearance of the bar chart
    private void initBarDataSet(BarDataSet barDataSet) {
        //Changing the color of the bar
//        barDataSet.setColor(Color.parseColor("#304567"));
        //Setting the size of the form in the legend
        barDataSet.setFormSize(15f);
        //showing the value of the bar, default true if not set
        barDataSet.setDrawValues(false);
        //setting the text size of the value of the bar
        barDataSet.setValueTextSize(12f);
        barDataSet.setDrawValues(false);

    }


    //function  responsible for the appearance of the bar chart
    private void initBarChart() {
        String[] annualLabels = new String[]{"jan", "feb", "mar", "apr", "may", "jun", "jul", "aug"
                , "sep", "oct", "nov", "dec"};
        String[] monthlyLabels = new String[]{"1", "2", "3", "4", "5"};
        String[] weeklyLabels = new String[]{"sun", "mon", "tue", "wed", "thu", "fri", "sat"};
        //hiding the grey background of the chart, default false if not set
        barChart.setDrawGridBackground(false);
        //remove the bar shadow, default false if not set
        barChart.setDrawBarShadow(false);
        //remove border of the chart, default false if not set
        barChart.setDrawBorders(false);

        barChart.setDragEnabled(true);
        barChart.setOnClickListener(null);
        //remove the description label text located at the lower right corner
        Description description = new Description();
        description.setEnabled(false);
        barChart.setDescription(description);


        barChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry entry, Highlight highlight) {
                barChart.getOnTouchListener().setLastHighlighted(null);
                barChart.highlightValues(null);
                //don't highlight when clicked
            }
            @Override
            public void onNothingSelected() {

            }
        });



        //setting animation for y-axis, the bar will pop up from 0 to its value within the time we set
        barChart.animateY(1000);
        //setting animation for x-axis, the bar will pop up separately within the time we set
        barChart.animateX(1000);

        XAxis xAxis = barChart.getXAxis();
        //change the position of x-axis to the bottom
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        //set the horizontal distance of the grid line
        xAxis.setGranularity(1f);
        //hiding the x-axis line, default true if not set
        xAxis.setDrawAxisLine(false);

        //hiding the vertical grid lines, default true if not set
        xAxis.setDrawGridLines(false);

        YAxis leftAxis = barChart.getAxisLeft();
        //hiding the left y-axis line, default true if not set
        leftAxis.setDrawAxisLine(false);

        YAxis rightAxis = barChart.getAxisRight();
        //hiding the right y-axis line, default true if not set
        rightAxis.setDrawAxisLine(false);

        rightAxis.setDrawLabels(false);
        switch (timecontrol) {
            case 1:
                xAxis.setValueFormatter(new IndexAxisValueFormatter(annualLabels));
                break;
            case 2:
                xAxis.setValueFormatter(new IndexAxisValueFormatter(monthlyLabels));
                break;
            case 3:
                xAxis.setValueFormatter(new IndexAxisValueFormatter(weeklyLabels));
                break;

        }

        Legend legend = barChart.getLegend();
        //setting the shape of the legend form to line, default square shape
        legend.setForm(Legend.LegendForm.LINE);
        //setting the text size of the legend
        legend.setTextSize(11f);
        //setting the alignment of legend toward the chart
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        //setting the stacking direction of legend
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        //setting the location of legend outside the chart, default false if not set
        legend.setDrawInside(false);
        legend.setEnabled(true);
        // setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        //  setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        //  barChart.setExtraOffsets(5f,5f,5f,15f);

        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);

        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        CustomBarChartRender barChartRender = new CustomBarChartRender(barChart, barChart.getAnimator(), barChart.getViewPortHandler());
        barChartRender.setRadius(12);
        barChart.setRenderer(barChartRender);
    }





}